package main

import (
 "flag"
 "log"
 "net"
 "github.com/gorilla/websocket"
 "io"
)

func startProxy(serverURL string) {
 l, _ := net.Listen("tcp", "127.0.0.1:1080")
 log.Println("✅ Proxy mode running on :1080")

 for {
  clientConn, _ := l.Accept()
  go func(c net.Conn) {
   ws, _, _ := websocket.DefaultDialer.Dial(serverURL, nil)
   defer ws.Close()
   defer c.Close()

   go io.Copy(c, ws.UnderlyingConn())
   io.Copy(ws.UnderlyingConn(), c)
  }(clientConn)
 }
}

func startVPN(serverURL string) {
 log.Println("🚧 VPN mode (TUN) is placeholder")
 log.Println("Gunakan tun2socks / wireguard integration untuk full VPN")
 select {}
}

func main() {
 mode := flag.String("mode", "proxy", "proxy | vpn")
 server := flag.String("server", "ws://localhost:8080/tunnel", "server websocket url")
 flag.Parse()

 if *mode == "vpn" {
  startVPN(*server)
 } else {
  startProxy(*server)
 }
}
